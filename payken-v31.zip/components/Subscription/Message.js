const Message = ({ message }) => (
    <section>
      <p>{message}</p>
    </section>
  );

  export default Message;