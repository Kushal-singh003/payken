import Index from '@/components/Dashboard/AllProducts/BuyProduct/PlaceOrder/Index'
import React from 'react'

export default function index() {
  return (
    <div>
        <Index/>
    </div>
  )
}
