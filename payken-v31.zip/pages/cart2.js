import Cart2 from '@/components/ui/Cart2'
import React from 'react'

export default function cart2() {
  return (
    <div>
        <Cart2/>
    </div>
  )
}
