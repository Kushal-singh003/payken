import TestPage from '@/components/Subscription/TestPage'
import React from 'react'

export default function testPage() {
  return (
    <div>
        <TestPage/>
    </div>
  )
}
