import Registration from '@/components/Registration/Index'
import React from 'react'

export default function index() {
  return (
    <div>
        <Registration/>
    </div>
  )
}
