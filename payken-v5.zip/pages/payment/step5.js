import Step5 from "@/components/Payment/Modal/step5";
import Footer from "@/components/ui/Footer";
import NavBar from "@/components/ui/NavBar";
import React from "react";

export default function step4() {
  return (
    <div>
      <NavBar/>
      <Step5 />
      
    </div>
  );
}
